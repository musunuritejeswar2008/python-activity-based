def main():
    try:
        balance = float(input("Starting balance (Rs.): "))
        if balance < 0:
            print("Starting balance cannot be negative.")
            return
    except ValueError:
        print("Enter a valid starting balance.")
        return

    deposits = 0.0
    withdrawals = 0.0
    rejected = 0
    print("Commands: DEPOSIT, WITHDRAW, DONE")
    while True:
        action = input("Transaction: ").strip().upper()
        if action == "DONE":
            break
        if action not in ("DEPOSIT", "WITHDRAW"):
            print("Rejected: unknown transaction type.")
            rejected += 1
            continue
        try:
            amount = float(input("Amount (Rs.): "))
        except ValueError:
            print("Rejected: amount must be numeric.")
            rejected += 1
            continue
        if amount <= 0:
            print("Rejected: amount must be positive.")
            rejected += 1
        elif action == "DEPOSIT":
            balance += amount
            deposits += amount
            print(f"Deposit successful. Balance: Rs. {balance:.2f}")
        elif amount > 10000:
            print("Rejected: withdrawal limit is Rs. 10000 per transaction.")
            rejected += 1
        elif amount > balance:
            print("Rejected: insufficient balance.")
            rejected += 1
        else:
            balance -= amount
            withdrawals += amount
            print(f"Withdrawal successful. Balance: Rs. {balance:.2f}")

    print("\n--- TRANSACTION SUMMARY ---")
    print(f"Total deposits: Rs. {deposits:.2f}")
    print(f"Total successful withdrawals: Rs. {withdrawals:.2f}")
    print(f"Rejected transactions: {rejected}")
    print(f"Final balance: Rs. {balance:.2f}")


if __name__ == "__main__":
    main()
