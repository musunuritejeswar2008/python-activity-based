# Case Study 5: ATM Transaction Sequence Simulation

## 1. Problem statement
Simulate a sequence of deposits and withdrawals, validate transactions, enforce a withdrawal limit, and summarize successful and rejected operations.

## 2. Objectives
- Maintain a running balance.
- Validate transaction types and amounts.
- Summarize deposits, withdrawals, and rejected transactions.

## 3. Assumptions
- Starting balance is entered by the user.
- Each withdrawal is limited to ₹10,000 and cannot exceed available balance.
- A transaction amount must be positive.
- This is a classroom simulation, not a real banking system.

## 4. Algorithm
1. Start.
2. Read and validate starting balance.
3. Repeatedly read transaction type and amount until DONE.
4. For deposits, add a positive amount to balance.
5. For withdrawals, check amount, limit, and available balance.
6. Record successful transactions and rejected attempts.
7. Print final balance and summary totals.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
INPUT starting_balance
SET deposits = 0, withdrawals = 0, rejected = 0
REPEAT INPUT transaction_type, amount until type = DONE
    IF amount <= 0: rejected += 1
    ELSE IF type = DEPOSIT: balance += amount; deposits += amount
    ELSE IF type = WITHDRAW: validate limit and balance; update if valid
    ELSE: rejected += 1
DISPLAY balance, deposits, withdrawals, rejected
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### deposit then withdraw
- Input / setup: start 1000; deposit 500; withdraw 200; done
- Expected result: deposits 500; withdrawals 200; final 1300

### withdraw more than balance
- Input / setup: start 100; withdraw 200
- Expected result: rejected; final 100

### over limit
- Input / setup: start 20000; withdraw 12000
- Expected result: rejected; final 20000

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The simulation demonstrates loops, validation, state updates, and transaction summaries while keeping the balance consistent.
