def main():
    students = ["Asha", "Bala", "Charan"]
    subjects = ["Python", "Maths", "English", "Computing"]
    marks = [
        [85, 78, 80, 92],
        [72, 88, 75, 81],
        [45, 55, 60, 50],
    ]

    if any(len(row) != len(subjects) for row in marks):
        print("Error: marks matrix dimensions do not match subjects.")
        return
    if any(mark < 0 or mark > 100 for row in marks for mark in row):
        print("Error: marks must be between 0 and 100.")
        return

    totals = []
    print("--- STUDENT RESULTS ---")
    for name, row in zip(students, marks):
        total = sum(row)
        totals.append(total)
        print(f"{name}: total={total}, average={total / len(subjects):.2f}")

    print("\n--- SUBJECT AVERAGES ---")
    low_subjects = []
    for column, subject in enumerate(subjects):
        average = sum(row[column] for row in marks) / len(students)
        print(f"{subject}: {average:.2f}")
        if average < 50:
            low_subjects.append(subject)

    best_total = max(totals)
    best_students = [students[i] for i, total in enumerate(totals) if total == best_total]
    print("Top performer(s):", ", ".join(best_students), f"(total {best_total})")
    print("Low-average subjects:", ", ".join(low_subjects) if low_subjects else "None")


if __name__ == "__main__":
    main()
