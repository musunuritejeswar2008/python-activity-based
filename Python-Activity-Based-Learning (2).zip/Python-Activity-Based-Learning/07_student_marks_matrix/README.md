# Case Study 7: Student Marks Matrix Analysis

## 1. Problem statement
Analyse a matrix of student marks across subjects, calculate student totals and subject averages, identify the top performer, and flag subjects with low averages.

## 2. Objectives
- Represent marks as a nested list.
- Calculate row-wise totals and column-wise averages.
- Identify the highest total and low-average subjects.

## 3. Assumptions
- Marks are out of 100.
- The sample matrix includes three students and four subjects.
- A subject average below 50 is considered low for this exercise.
- Ties for top total are all reported.

## 4. Algorithm
1. Start.
2. Define student names, subject names, and marks matrix.
3. Validate matrix dimensions and mark range.
4. Calculate each student total and average.
5. Calculate each subject average.
6. Find maximum student total and report ties.
7. Flag subjects whose average is below 50.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
DEFINE students, subjects, marks nested list
FOR each student row: calculate total and average
FOR each subject column: calculate average
max_total = maximum student total
DISPLAY every student whose total = max_total
DISPLAY subjects with average < 50
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### standard sample
- Input / setup: run without input
- Expected result: Asha total 335; Bala total 316; Charan total 210; top Asha

### low average threshold
- Input / setup: sample matrix
- Expected result: No subject average below 50 in current sample

### invalid mark
- Input / setup: mark 105
- Expected result: Validation error (if data changed to 105)

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The program demonstrates nested lists, loops, indexing, zip, and column-wise analysis of a marks matrix.
