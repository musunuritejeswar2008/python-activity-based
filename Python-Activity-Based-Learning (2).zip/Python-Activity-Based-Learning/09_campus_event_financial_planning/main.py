def main():
    try:
        participants = int(input("Expected participants: "))
        sponsorship = float(input("Sponsorship amount (Rs.): "))
        if participants < 0 or sponsorship < 0:
            print("Error: values cannot be negative.")
            return
    except ValueError:
        print("Error: enter a whole participant count and numeric sponsorship.")
        return

    venue = 8000.0
    equipment = 3000.0
    certificate_per_person = 20.0
    catering_per_person = 150.0
    registration_fee = 250.0
    fixed_cost = venue + equipment
    variable_cost = participants * (certificate_per_person + catering_per_person)
    total_cost = fixed_cost + variable_cost
    registration_income = participants * registration_fee
    total_funding = sponsorship + registration_income
    balance = total_funding - total_cost

    required = 0
    while sponsorship + required * registration_fee < fixed_cost + required * (certificate_per_person + catering_per_person):
        required += 1

    print("--- EVENT FINANCIAL PLAN ---")
    print(f"Fixed costs: Rs. {fixed_cost:.2f}")
    print(f"Variable costs: Rs. {variable_cost:.2f}")
    print(f"Total cost: Rs. {total_cost:.2f}")
    print(f"Registration income: Rs. {registration_income:.2f}")
    print(f"Sponsorship: Rs. {sponsorship:.2f}")
    print(f"Final balance: Rs. {balance:.2f}")
    print(f"Minimum registrations needed to break even with this sponsorship: {required}")
    if balance < 0:
        print(f"Current funding shortfall: Rs. {-balance:.2f}")
    else:
        print("Current plan covers the estimated cost.")


if __name__ == "__main__":
    main()
