# Case Study 9: Campus Event Financial Planning

## 1. Problem statement
Calculate campus event costs, participant contributions, sponsorship shortfall, and the minimum number of registrations needed to break even.

## 2. Objectives
- Add fixed and per-participant expenses.
- Calculate funding shortfall after sponsorship.
- Find minimum registrations needed to cover cost.

## 3. Assumptions
- Venue ₹8,000, equipment ₹3,000, certificates ₹20 per participant, catering ₹150 per participant.
- Sponsorship is entered by the user.
- Each registration contributes ₹250.
- If fixed costs exceed sponsorship, break-even registration count is calculated with a ceiling-style loop.

## 4. Algorithm
1. Start.
2. Read participant count and sponsorship.
3. Validate non-negative values.
4. Calculate fixed costs and variable costs.
5. Calculate total cost, registration income and balance.
6. Calculate sponsorship shortfall if any.
7. Loop to find the minimum registration count that covers cost after sponsorship.
8. Display financial summary.
9. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
INPUT participants, sponsorship
fixed_cost = venue + equipment
variable_cost = participants * (certificate_cost + catering_cost)
total_cost = fixed_cost + variable_cost
registration_income = participants * 250
balance = sponsorship + registration_income - total_cost
required = 0
WHILE sponsorship + required * 250 < fixed_cost + required * 170: required += 1
DISPLAY totals, balance, required registrations
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### 100 participants, 10000 sponsor
- Input / setup: 100, 10000
- Expected result: cost 28000; registration income 25000; balance 7000; break-even registrations 13

### 0 participants, no sponsor
- Input / setup: 0, 0
- Expected result: cost 11000; balance -11000; break-even registrations 138

### negative count
- Input / setup: -2, 1000
- Expected result: Error message

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The program uses arithmetic, loops, and conditions to estimate event finances and identify break-even registrations.
