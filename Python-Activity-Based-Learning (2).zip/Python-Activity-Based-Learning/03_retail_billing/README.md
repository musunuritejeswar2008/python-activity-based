# Case Study 3: Retail Billing with Multiple Discount Rules

## 1. Problem statement
Generate an itemized retail invoice for several products, applying quantity, category tax, a threshold discount, and a maximum discount cap.

## 2. Objectives
- Store product records using lists and tuples.
- Calculate subtotal, category taxes, and eligible discount.
- Generate a final invoice and test invalid quantities.

## 3. Assumptions
- Three sample products are included in the program.
- Electronics tax is 18%; grocery tax is 5%; stationery tax is 12%.
- A 10% discount applies to subtotal at least ₹2,000, capped at ₹500.
- Quantities must be positive integers.

## 4. Algorithm
1. Start.
2. Define product catalogue as tuples.
3. Read product code and quantity repeatedly until DONE.
4. Validate product code and quantity.
5. Calculate each line subtotal and tax.
6. Apply the eligible discount, limited to ₹500.
7. Calculate final payable amount and display invoice.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
DEFINE catalogue tuples (code, name, price, category)
SET subtotal = 0, tax_total = 0
REPEAT read code and quantity until code = DONE
    VALIDATE code and quantity
    line = price * quantity
    subtotal = subtotal + line
    tax_total = tax_total + line * category_tax_rate
IF subtotal >= 2000: discount = MIN(subtotal * 0.10, 500)
ELSE discount = 0
DISPLAY subtotal, tax_total, discount, subtotal + tax_total - discount
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### one notebook x 2
- Input / setup: P101, 2, DONE
- Expected result: Subtotal 120; tax 14.40; discount 0; payable 134.40

### headphones x 2
- Input / setup: P102, 2, DONE
- Expected result: Subtotal 2400; tax 432; discount 240; payable 2592

### quantity 0
- Input / setup: P101, 0
- Expected result: Validation message; item not added

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The invoice uses dictionaries, tuples, loops, conditions, and arithmetic to calculate a transparent bill.
