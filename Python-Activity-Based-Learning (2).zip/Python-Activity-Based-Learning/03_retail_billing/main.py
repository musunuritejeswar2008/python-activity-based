# Catalogue records: (code, product name, unit price, category)
PRODUCTS = {
    "P101": ("Notebook", 60.0, "stationery"),
    "P102": ("Headphones", 1200.0, "electronics"),
    "P103": ("Rice bag", 800.0, "grocery"),
}
TAX_RATES = {"electronics": 0.18, "grocery": 0.05, "stationery": 0.12}


def main():
    subtotal = 0.0
    tax_total = 0.0
    invoice = []
    print("Products:", ", ".join(f"{code}={data[0]} Rs.{data[1]:.2f}" for code, data in PRODUCTS.items()))
    print("Enter DONE as product code to finish.")
    while True:
        code = input("Product code: ").strip().upper()
        if code == "DONE":
            break
        if code not in PRODUCTS:
            print("Unknown product code. Try again.")
            continue
        try:
            quantity = int(input("Quantity: "))
            if quantity <= 0:
                print("Quantity must be a positive integer.")
                continue
        except ValueError:
            print("Quantity must be a whole number.")
            continue
        name, price, category = PRODUCTS[code]
        line_total = price * quantity
        line_tax = line_total * TAX_RATES[category]
        invoice.append((name, quantity, price, line_total, line_tax))
        subtotal += line_total
        tax_total += line_tax
    discount = min(subtotal * 0.10, 500.0) if subtotal >= 2000 else 0.0
    payable = subtotal + tax_total - discount
    print("\n--- ITEMIZED INVOICE ---")
    for name, quantity, price, line_total, line_tax in invoice:
        print(f"{name}: {quantity} x Rs.{price:.2f} = Rs.{line_total:.2f}; tax Rs.{line_tax:.2f}")
    print(f"Subtotal: Rs. {subtotal:.2f}")
    print(f"Tax total: Rs. {tax_total:.2f}")
    print(f"Discount: Rs. {discount:.2f}")
    print(f"Amount payable: Rs. {payable:.2f}")


if __name__ == "__main__":
    main()
