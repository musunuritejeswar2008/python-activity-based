# Python Activity-Based Learning (ABL) Assignment

**Repository name required by the circular:** `Python-Activity-Based-Learning`

This project contains 10 case studies selected from the faculty-provided case-study list. Each case folder includes the Python program, problem documentation, algorithm, text flowchart, pseudocode, test cases, and sample output.

## Case studies included
1. Progressive Electricity Billing (case study 2)
2. Employee Payroll and Deduction Analysis (case study 4)
3. Retail Billing with Multiple Discount Rules (case study 7)
4. Attendance Recovery Computation (case study 12)
5. ATM Transaction Sequence Simulation (case study 13)
6. Password Policy Validation Engine (case study 29)
7. Student Marks Matrix Analysis (case study 42)
8. Tuple-Based Employee Shift Conflict Detection (case study 48)
9. Campus Event Financial Planning (case study 10)
10. Student Email and Identifier Validation (case study 30)

## How to run on Windows 10 / PyCharm
1. Extract the ZIP file.
2. Open the extracted `Python-Activity-Based-Learning` folder in PyCharm.
3. Open any case folder and run its `.py` file.
4. Use the sample test inputs listed in that folder's `README.md` / `test_cases.txt`.
5. Programs use only standard Python features; no external packages are required.

## Before submission
- Replace the student details in `STUDENT_DETAILS.txt` with your own correct name, roll number, branch, and section.
- Run each program yourself and capture actual output screenshots. Place screenshots in the matching case folder under `screenshots/`.
- Read and understand every algorithm and code file; the circular says the assignment is individual and you must be able to explain and demonstrate your programs.
- Review sample assumptions and rates with your faculty if they provided different rules.
- Upload the project contents to your own GitHub repository named `Python-Activity-Based-Learning`, then submit the repository URL as instructed by your college.

## Important note
The rates, thresholds, and sample records in these solutions are explicitly stated educational assumptions where the case-study list does not provide exact values. They are not official electricity, payroll, tax, banking, or institutional rules.
