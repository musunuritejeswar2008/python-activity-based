def format_time(minutes):
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def main():
    # (employee, start time in minutes, end time in minutes)
    shifts = [
        ("Anu", 9 * 60, 12 * 60),
        ("Anu", 11 * 60, 14 * 60),
        ("Ravi", 9 * 60 + 30, 12 * 60 + 30),
        ("Anu", 14 * 60, 16 * 60),
    ]
    for employee, start, end in shifts:
        if not (0 <= start < end <= 24 * 60):
            print(f"Invalid shift for {employee}: {start}, {end}")
            return

    conflicts = []
    for i in range(len(shifts)):
        for j in range(i + 1, len(shifts)):
            employee1, start1, end1 = shifts[i]
            employee2, start2, end2 = shifts[j]
            if employee1 == employee2 and max(start1, start2) < min(end1, end2):
                conflicts.append((employee1, shifts[i], shifts[j]))

    if not conflicts:
        print("No shift conflicts found.")
    else:
        print("--- SHIFT CONFLICTS ---")
        for employee, first, second in conflicts:
            print(f"{employee}: {format_time(first[1])}-{format_time(first[2])} overlaps "
                  f"{format_time(second[1])}-{format_time(second[2])}")


if __name__ == "__main__":
    main()
