# Case Study 8: Tuple-Based Employee Shift Conflict Detection

## 1. Problem statement
Represent employee shifts as tuples, compare time intervals, detect overlapping assignments for the same employee, and report conflicts.

## 2. Objectives
- Store records using tuples.
- Compare start and end times.
- Detect overlapping shifts for an employee.

## 3. Assumptions
- Times are represented as minutes after midnight on the same day.
- A shift is a tuple (employee, start_minutes, end_minutes).
- Start time must be less than end time.
- Two shifts overlap when max(start1, start2) is less than min(end1, end2).

## 4. Algorithm
1. Start.
2. Create a list of shift tuples.
3. Validate each time interval.
4. Compare every pair of shifts.
5. If employee names match and time intervals overlap, record the pair.
6. Display conflicts or report none.
7. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
DEFINE shifts as tuples (employee, start, end)
FOR each shift: validate start < end
FOR i from 0 to number_of_shifts - 1:
    FOR j from i + 1 to number_of_shifts - 1:
        IF employee names match AND max(starts) < min(ends): record conflict
DISPLAY conflicts
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### sample overlap
- Input / setup: Anu 09:00-12:00 and 11:00-14:00
- Expected result: Conflict reported from 09:00-12:00 and 11:00-14:00

### different employees
- Input / setup: Anu 09:00-12:00; Ravi 09:30-12:30
- Expected result: No conflict between different employees

### touching boundary
- Input / setup: same employee 09:00-10:00 and 10:00-11:00
- Expected result: No overlap; intervals only touch

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The program applies tuple storage, nested loops, and interval comparisons to identify conflicting assignments.
