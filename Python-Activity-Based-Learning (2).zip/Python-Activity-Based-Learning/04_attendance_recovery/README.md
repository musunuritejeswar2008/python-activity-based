# Case Study 4: Attendance Recovery Computation

## 1. Problem statement
Calculate current attendance percentage and determine the minimum number of consecutive attended classes needed to reach a required attendance threshold.

## 2. Objectives
- Calculate attendance percentage.
- Use a loop to find required future classes.
- Handle invalid counts and already-eligible students.

## 3. Assumptions
- The default eligibility threshold is 75%.
- Future classes are assumed to be attended.
- Classes conducted must be greater than zero and attended classes cannot exceed conducted classes.

## 4. Algorithm
1. Start.
2. Read classes conducted, classes attended and threshold.
3. Validate input counts and threshold.
4. Calculate current attendance percentage.
5. If current percentage meets threshold, required classes are zero.
6. Otherwise increase future attended classes one by one until the ratio reaches threshold.
7. Display percentage and minimum classes needed.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
INPUT conducted, attended, threshold
VALIDATE 0 <= attended <= conducted and conducted > 0
percentage = attended / conducted * 100
future = 0
WHILE (attended + future) / (conducted + future) * 100 < threshold:
    future = future + 1
DISPLAY percentage, future
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### 40/50
- Input / setup: conducted 50, attended 40
- Expected result: 80.00%; already meets threshold

### 30/50
- Input / setup: conducted 50, attended 30
- Expected result: 60.00%; 30 future classes needed to reach 75%

### attended > conducted
- Input / setup: conducted 10, attended 12
- Expected result: Error message

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The program uses loops and conditional statements to find the minimum future classes required to reach an attendance target.
