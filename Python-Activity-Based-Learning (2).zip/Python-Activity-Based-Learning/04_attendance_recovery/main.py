def main():
    try:
        conducted = int(input("Classes conducted: "))
        attended = int(input("Classes attended: "))
        threshold = float(input("Required attendance percentage (default 75): ") or "75")
        if conducted <= 0 or attended < 0 or attended > conducted or not 0 < threshold <= 100:
            print("Error: check class counts and threshold (0-100].")
            return
        current = attended / conducted * 100
        future = 0
        while (attended + future) / (conducted + future) * 100 < threshold:
            future += 1
        print(f"Current attendance: {current:.2f}%")
        if future == 0:
            print("You already meet the attendance threshold.")
        else:
            print(f"Minimum consecutive classes to attend: {future}")
            final_percentage = (attended + future) / (conducted + future) * 100
            print(f"Attendance after attending them: {final_percentage:.2f}%")
    except ValueError:
        print("Error: enter whole numbers for classes and a valid percentage.")


if __name__ == "__main__":
    main()
