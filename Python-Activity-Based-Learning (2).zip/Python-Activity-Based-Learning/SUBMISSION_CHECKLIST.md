# Submission checklist

- [ ] Fill `STUDENT_DETAILS.txt`.
- [ ] Run all 10 `.py` programs in PyCharm.
- [ ] Test normal and invalid input cases.
- [ ] Capture real output screenshots and save them in each `screenshots/` folder.
- [ ] Read and understand each program well enough to explain it.
- [ ] Check the consolidated PDF report.
- [ ] Create your GitHub repository named `Python-Activity-Based-Learning`.
- [ ] Upload the project files and verify the repository is public or accessible to your faculty.
- [ ] Submit the repository URL to the faculty / lab mentor.

**Do not submit fabricated screenshots.** The text output files are reference outputs; generate screenshots from your own PyCharm run.
