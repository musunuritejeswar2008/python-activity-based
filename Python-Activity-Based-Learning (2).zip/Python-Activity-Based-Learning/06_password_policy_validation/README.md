# Case Study 6: Password Policy Validation Engine

## 1. Problem statement
Evaluate sample password strings against length, character-category, repeated-character, and prohibited-substring rules, and explain which rules fail.

## 2. Objectives
- Apply basic string operations.
- Check several password policy rules.
- Report every failed condition rather than only one.

## 3. Assumptions
- Minimum length is 8 characters.
- A valid sample must contain lowercase, uppercase, a digit, and a non-alphanumeric character.
- Three identical consecutive characters are prohibited.
- The substring “password” is prohibited regardless of case.
- Do not enter or test a real password; use fictional examples only.

## 4. Algorithm
1. Start.
2. Read a fictional sample password.
3. Check length and character categories.
4. Check for three identical consecutive characters.
5. Check whether prohibited substring appears case-insensitively.
6. Collect failed rules in a list.
7. Print VALID or INVALID and list the reasons.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
INPUT fictional_sample
SET failures = empty list
CHECK length >= 8
CHECK lowercase, uppercase, digit, special character
CHECK no 3 identical consecutive characters
CHECK substring "password" is absent ignoring case
IF failures empty: DISPLAY policy passed
ELSE DISPLAY each failed rule
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### valid fictional example
- Input / setup: Abc@1234
- Expected result: VALID

### too short
- Input / setup: abc
- Expected result: INVALID: length, uppercase, digit, special character

### prohibited substring
- Input / setup: Password@123
- Expected result: INVALID: prohibited substring

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The validator uses string methods, loops, lists, and conditions to explain policy failures. It is a classroom demonstration, not a full security audit.
