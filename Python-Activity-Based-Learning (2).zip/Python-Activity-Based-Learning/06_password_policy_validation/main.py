def validate_password(sample):
    failures = []
    if len(sample) < 8:
        failures.append("At least 8 characters are required.")
    if not any(char.islower() for char in sample):
        failures.append("Include a lowercase letter.")
    if not any(char.isupper() for char in sample):
        failures.append("Include an uppercase letter.")
    if not any(char.isdigit() for char in sample):
        failures.append("Include a digit.")
    if not any(not char.isalnum() for char in sample):
        failures.append("Include a special character.")
    for index in range(len(sample) - 2):
        if sample[index] == sample[index + 1] == sample[index + 2]:
            failures.append("Three identical consecutive characters are not allowed.")
            break
    if "password" in sample.lower():
        failures.append("The substring 'password' is not allowed.")
    return failures


def main():
    print("Use a fictional sample only; do not enter a real password.")
    sample = input("Fictional sample: ")
    failures = validate_password(sample)
    if not failures:
        print("Result: VALID under this sample policy.")
    else:
        print("Result: INVALID under this sample policy.")
        for reason in failures:
            print("-", reason)


if __name__ == "__main__":
    main()
