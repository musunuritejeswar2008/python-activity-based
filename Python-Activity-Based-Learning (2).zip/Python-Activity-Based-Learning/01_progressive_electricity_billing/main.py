def energy_charge(units):
    """Return the progressive energy charge for non-negative units."""
    if units < 0:
        raise ValueError("Units cannot be negative.")
    if units <= 100:
        return units * 1.50
    if units <= 200:
        return 100 * 1.50 + (units - 100) * 2.50
    return 100 * 1.50 + 100 * 2.50 + (units - 200) * 4.00


def bill(units):
    fixed_charge = 50.0
    total = energy_charge(units) + fixed_charge
    if units <= 100:
        total *= 0.95  # 5% rebate on the bill subtotal
    return round(total, 2)


def main():
    try:
        current = float(input("Current month units: "))
        previous = float(input("Previous month units: "))
        if current < 0 or previous < 0:
            print("Error: units cannot be negative.")
            return
        current_bill = bill(current)
        previous_bill = bill(previous)
        print(f"Previous bill: Rs. {previous_bill:.2f}")
        print(f"Current bill: Rs. {current_bill:.2f}")
        if previous_bill == 0:
            print("Percentage change: not available (previous bill is zero).")
        else:
            change = (current_bill - previous_bill) / previous_bill * 100
            print(f"Bill change: {change:.2f}%")
            if change > 30:
                print("Notice: unusual bill increase.")
            else:
                print("Notice: no unusual increase detected.")
    except ValueError:
        print("Error: enter valid numeric values.")


if __name__ == "__main__":
    main()
