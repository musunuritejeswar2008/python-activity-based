# Case Study 1: Progressive Electricity Billing

## 1. Problem statement
Calculate a household electricity bill using progressive consumption slabs, a fixed charge, and a rebate when consumption is low. Compare bills across months and flag a large increase.

## 2. Objectives
- Calculate energy charges using progressive slabs.
- Apply fixed charges and a conditional rebate.
- Compare two monthly bills and flag a large increase.

## 3. Assumptions
- Sample tariff values are for this assignment only, not an actual utility tariff.
- First 100 units cost ₹1.50/unit; next 100 cost ₹2.50/unit; units above 200 cost ₹4/unit.
- Fixed charge is ₹50. A 5% rebate applies when consumption is at most 100 units.
- An increase above 30% is flagged as unusual.

## 4. Algorithm
1. Start.
2. Read current-month and previous-month units.
3. Validate both values are non-negative.
4. Calculate progressive energy charges for each month.
5. Add fixed charge and apply the low-consumption rebate.
6. Calculate percentage increase when the previous bill is non-zero.
7. Display both bills and the unusual-increase message.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
INPUT current_units, previous_units
IF either units value < 0: report invalid input
FOR each units value:
    charge = slab_charge(units) + fixed_charge
    IF units <= 100: apply 5% rebate
IF previous_bill > 0: increase = (current_bill - previous_bill) / previous_bill * 100
DISPLAY bills and comparison
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### 80 units
- Input / setup: Previous 80, current 80
- Expected result: Previous bill Rs. 161.50; current bill Rs. 161.50; change 0.00%

### previous 100, current 250
- Input / setup: 100, 250
- Expected result: Previous bill Rs. 190.00; current bill Rs. 650.00; unusual increase

### negative input
- Input / setup: -5, 20
- Expected result: Error: units cannot be negative.

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The program applies progressive rates, a conditional rebate, and month-to-month comparison using functions, selection, and arithmetic operators.
