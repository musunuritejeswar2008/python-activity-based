def progressive_deduction(gross):
    if gross <= 10000:
        return gross * 0.00
    if gross <= 20000:
        return 10000 * 0.00 + (gross - 10000) * 0.05
    return 10000 * 0.00 + 10000 * 0.05 + (gross - 20000) * 0.10


def main():
    name = input("Employee name: ").strip()
    try:
        basic = float(input("Basic pay (Rs.): "))
        overtime_hours = float(input("Overtime hours: "))
        incentive = float(input("Incentive (Rs.): "))
        if not name or min(basic, overtime_hours, incentive) < 0:
            print("Error: name is required and amounts cannot be negative.")
            return
        hra = basic * 0.20
        travel = 1500.0
        overtime_pay = overtime_hours * 200.0
        gross = basic + hra + travel + overtime_pay + incentive
        income_deduction = progressive_deduction(gross)
        welfare = 200.0
        net = gross - income_deduction - welfare
        print("\n--- SALARY STATEMENT ---")
        print(f"Employee: {name}")
        print(f"Basic pay: Rs. {basic:.2f}")
        print(f"HRA: Rs. {hra:.2f}")
        print(f"Travel allowance: Rs. {travel:.2f}")
        print(f"Overtime pay: Rs. {overtime_pay:.2f}")
        print(f"Incentive: Rs. {incentive:.2f}")
        print(f"Gross salary: Rs. {gross:.2f}")
        print(f"Income deduction: Rs. {income_deduction:.2f}")
        print(f"Welfare deduction: Rs. {welfare:.2f}")
        print(f"Net salary: Rs. {net:.2f}")
    except ValueError:
        print("Error: enter valid numeric values.")


if __name__ == "__main__":
    main()
