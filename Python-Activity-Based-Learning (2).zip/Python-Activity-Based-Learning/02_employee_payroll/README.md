# Case Study 2: Employee Payroll and Deduction Analysis

## 1. Problem statement
Calculate an employee’s gross salary from basic pay, allowances, overtime and incentives, then apply progressive deductions and print a salary statement.

## 2. Objectives
- Compute gross salary from multiple components.
- Calculate deductions using defined salary bands.
- Print a readable salary statement.

## 3. Assumptions
- All amounts are in rupees and are sample educational rules.
- HRA is 20% of basic pay; travel allowance is ₹1,500; overtime is paid at ₹200/hour.
- Income deduction: 0% on first ₹10,000, 5% on the next ₹10,000, and 10% above ₹20,000 of gross salary.
- A fixed welfare deduction of ₹200 is applied.

## 4. Algorithm
1. Start.
2. Read employee name, basic pay, overtime hours, and incentive.
3. Validate numeric inputs are non-negative.
4. Calculate HRA, travel allowance, overtime pay and gross salary.
5. Calculate progressive income deduction and welfare deduction.
6. Calculate net salary.
7. Print itemized salary statement.
8. Stop.

## 5. Flowchart
```text
START
  |
INPUT / DEFINE DATA
  |
VALIDATE INPUT
  |
PROCESS USING CONDITIONS / LOOPS
  |
DISPLAY RESULT
  |
STOP
```

This text flowchart shows the main control flow. The detailed decisions and calculations are described in the algorithm and implemented in `main.py`.

## 6. Pseudocode
```text
INPUT name, basic, overtime_hours, incentive
VALIDATE numeric values >= 0
hra = basic * 0.20
overtime_pay = overtime_hours * 200
gross = basic + hra + 1500 + overtime_pay + incentive
CALCULATE progressive deduction on gross
net = gross - income_deduction - 200
DISPLAY salary statement
```

## 7. Python source code
See `main.py` in this folder.

## 8. Test cases
### basic 20000, overtime 2, incentive 1000
- Input / setup: Gross Rs. 26900.00
- Expected result: Income deduction Rs. 1190.00; net Rs. 25510.00

### zero values
- Input / setup: basic 0, overtime 0, incentive 0
- Expected result: Gross Rs. 1500.00; net Rs. 1300.00

### negative basic
- Input / setup: basic -1
- Expected result: Error message

## 9. Sample output
See `sample_output.txt`. This is a reference output description; run the program and capture your own screenshots in `screenshots/` before submission.

## 10. Conclusion
The program demonstrates input validation, percentage calculations, progressive deductions, and formatted output.
